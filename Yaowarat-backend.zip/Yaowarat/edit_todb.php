<?php
	
	include("connectSQL/connection.php");

	$review_id = $_POST['review_id'];
	$name = $_POST['name'];
	$price = $_POST['price'];
	$opent = $_POST['opent'];
	$location = $_POST['location'];
	$review = $_POST['review'];
	$image = $_POST['image'];
	$upload=$_FILES['image'];

	echo $name;

	if($upload <> '') {
	$path="images/"; 

	$remove_these = array(' ','`','"','/');
	$newname = str_replace($remove_these, '', $_FILES['image']['name']);	

	$newname = time().'-'.$newname;
	$path_copy=$path.$newname;
	$path_link="images/".$newname;

	move_uploaded_file($_FILES['image']['tmp_name'],$path_copy);

	$sql = "UPDATE yaowarat_review SET review_name='$name', review_price='$price', review_opent='$opent', review_location='$location', review='$review', review_img='$newname'WHERE review_id = '$review_id'";

	echo $sql;

	$query = mysql_query($sql);

	if($query){
		echo "Success";
		header('Refresh: 1;url=all-review.php');
	}else{
		echo mysql_errno();
		echo mysql_error();
		echo "0 result";
	}//end if result

}
	// ////////////////////

?>
<!-- <html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title></title>
</head>
<body>
	<a href="result.php">ดูไฟล์ที่อัพโหลด</a>
	<a href="add.php">กลับหน้า add ข้อมูล</a>
</body>
</html> -->