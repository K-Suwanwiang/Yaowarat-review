<?php

	include("connectSQL/connection.php");

	$name = $_POST['name'];
	$price = $_POST['price'];
	$opent = $_POST['opent'];
	$location = $_POST['location'];
	$review = $_POST['review'];
	$image = $_POST['image'];
	$upload=$_FILES['image'];


	if($upload <> '') {
	$path="images/"; 

	$remove_these = array(' ','`','"','/');
	$newname = str_replace($remove_these, '', $_FILES['image']['name']);	

	$newname = time().'-'.$newname;
	$path_copy=$path.$newname;
	$path_link="images/".$newname;

	move_uploaded_file($_FILES['image']['tmp_name'],$path_copy); 

	$sql = "INSERT INTO yaowarat_review (review_name,review_price,review_opent,review_location,review,review_img) VALUES ('$name','$price','$opent','$location','$review','$newname')";
	$query = mysql_query($sql);

	if($query){
		echo "Success";
		header('Refresh: 1;url=all-review.php');
	}else{
		echo "0 result";
	}//end if result

}
	// ////////////////////

?>
<!-- <html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title></title>
</head>
<body>
	<a href="result.php">ดูไฟล์ที่อัพโหลด</a>
	<a href="add.php">กลับหน้า add ข้อมูล</a>
</body>
</html> -->