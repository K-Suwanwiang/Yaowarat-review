<html>
<head>
	<title>Edit REVIEW</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<?php 
		$review_id_edit = $_GET['id'];
		echo "ID FOR EDIT MENU = ".$review_id_edit."<br>";
		include("connectSQL/connection.php");

		$sql = "SELECT * FROM yaowarat_review WHERE review_id=$review_id_edit";
		// require "connectSQL/connection.php";
		$result = mysql_query($sql);
		if(mysql_num_rows($result) > 0){
			while ($objResult = mysql_fetch_array($result)) {
				$reviewID = $objResult['review_id'];
				$reviewName = $objResult['review_name'];
				$reviewPrice = $objResult['review_price'];
				$reviewOpent = $objResult['review_opent'];
				$locationReview = $objResult['review_location'];
				$reviewReview = $objResult['review'];
				$reviewImg = $objResult['review_img'];

				echo $reviewName;
			}
		}else{
			echo "0 result";
		}//end 0 result
	?>
	<div id="tab-menu">
		<a href="index.php"><div class="logo"><img src="img/logo.png" height="49" width="53"></div></a>
		<div class="list-menu">
			<ul class="tab">
				 <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'London')">USER</a></li>
				 <li><a href="all-review.php" class="tablinks" onclick="openCity(event, 'Paris')">REVIEW</a></li>
				 <li><a href="add.php" class="tablinks" onclick="openCity(event, 'Tokyo')">ADD REVIEW</a></li>
			</ul>
		</div>
	</div><!-- tab-menu -->

	<center>
	<form class="add-box" action="edit_todb.php" method="post" enctype="multipart/form-data">
		<h3> Review Topic : </h3>
		<input type="text" placeholder="add topic" name="name" value="<?php echo $reviewName;?>" required/><br>
		<h3> Rate Price : </h3>
		<input type="text" placeholder="rate price" name="price" value="<?php echo $reviewPrice;?>" required/><br>
		<h3> Time Close : </h3>
		<input type="text" placeholder="time close" name="opent" value="<?php echo $reviewOpent; ?>" required/><br>
		<h3> Location : </h3>
		<input type="text" placeholder="location" name="location" value="<?php echo $locationReview;?>" required/><br>
		<h3> Review Detail : </h3>
		<input type="text" placeholder="add review details" name="review" value="<?php echo $reviewReview; ?>" required/><br>
		<h3> Upload Photo : </h3>
		<input type="file" value="<?php echo $reviewImg; ?>" name="image" required/><br>

		<input type="hidden" name="review_id"  value="<?php echo $reviewID;?>">
		
		<center> 
		<button type="submit">ADD REVIEW</button> </center>
	</form>
	</center>

</body>
</html>



