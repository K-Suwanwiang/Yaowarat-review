<!DOCTYPE html>
<html>
<head>
	<title>All Review</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="tab-menu">
		<a href="index.php"><div class="logo"><img src="img/logo.png" height="49" width="53"></div></a>
		<div class="list-menu">
			<ul class="tab">
				 <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'London')">USER</a></li>
				 <li><a href="all-review.php" class="tablinks" onclick="openCity(event, 'Paris')">REVIEW</a></li>
				 <li><a href="add.php" class="tablinks" onclick="openCity(event, 'Tokyo')">ADD REVIEW</a></li>
			</ul>
		</div>
	</div><!-- tab-menu -->

<?php 
	include("connectSQL/connection.php");

	$sql = "SELECT * FROM yaowarat_review";
	$query = mysql_query($sql);

	$row = mysql_num_rows($query);

	echo "<table border='1' align='center'>";

	echo 
	"<tr align='center'>
		<td> id </td>
		<td> Name </td>
		<td> Price </td>
		<td> Time </td>
		<td> Location </td>
		<td> Review Detail </td>
		<td> Image </td>
		<td> Edit/Delete</td>

	</tr>";

	while($objResult = mysql_fetch_array($query)){ 
		echo "<tr>";
		echo "<td class='td_id'>".$objResult["review_id"]."</td>";
		echo "<td class='td_name'>".$objResult["review_name"]."</td>";
		echo "<td class='td_price'>".$objResult["review_price"]."</td>";
		echo "<td class='td_opent'>".$objResult["review_opent"]."</td>";
		echo "<td class='td_location'>".$objResult["review_location"]."</td>";
		echo "<td class='td_location'>".$objResult["review"]."</td>";
		echo "<td class='td_review_img2'>"."<img src='images/".$objResult["review_img"]."' width='100'>"."</td>";?>

		<td>
			<a href="edit.php?id=<?php echo $objResult['review_id'];?>">
				<img src="img/btn_edit.png" height="15" width="15">
			</a> 
		|

			<a href="delete.php?id=<?php echo $objResult['review_id'];?>" onclick="return confirm('SURE');">
				<img src="img/btn_delete.png" height="15" width="15">
			</a>
			</td>
		<? echo "</tr>";
	 } 
	echo "</table>";
 ?>
	<!-- <div class="table">
		<table>
		  <tr>
		    <th>Name</th>
		    <th>Price</th>
		    <th>Time</th>
		    <th>Location</th>
		    <th>Review Detail</th>
		    <th>Image</th>
		  </tr>
		  <tr>
		    <td>Peter</td>
		    <td>Griffin</td>
		    <td>$100</td>
		  </tr>
	</div> -->

</body>
</html>














