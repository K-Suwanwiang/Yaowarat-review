<?php
	include("connectSQL/connection.php");

?>
<html>
<head>
	<title>ADD REVIEW</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<div id="tab-menu">
		<a href="index.php"><div class="logo"><img src="img/logo.png" height="49" width="53"></div></a>
		<div class="list-menu">
			<ul class="tab">
				<li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'London')">USER</a></li>
				<li><a href="all-review.php" class="tablinks" onclick="openCity(event, 'Paris')">REVIEW</a>  </li>
				<li><a href="add.php" class="tablinks" onclick="openCity(event, 'Tokyo')">ADD REVIEW</a></li>
			</ul>
		</div>
	</div><!-- tab-menu -->

	<center>
	<form class="add-box" action="success.php" method="post" enctype="multipart/form-data">
		<h3> Review Topic : </h3>
		<input type="text" placeholder="add topic" name="name" required/><br>
		<h3> Rate Price : </h3>
		<input type="text" placeholder="rate price" name="price" required/><br>
		<h3> Time Close : </h3>
		<input type="text" placeholder="time close" name="opent" required/><br>
		<h3> Location : </h3>
		<input type="text" placeholder="location" name="location" required/><br>
		<h3> Review Detail : </h3>
		<input type="text" placeholder="add review details" name="review" required/><br>
		<h3> Upload Photo : </h3>
		<input type="file" value="img" name="image" required/><br>

		<input name="review_id" type="hidden" value="Add">
		<center> <button type="submit">ADD REVIEW</button> </center>
	</form>
	</center>
</body>
</html>