<?php
	$objConnect = mysql_connect("ap-cdbr-azure-southeast-b.cloudapp.net","bb1c6298a02df8","b3da3e71");
    $objDB = mysql_select_db("acsm_6f40e825d2a18e3");

    // $_POST["strUser"]="user_01";
    // $_POST["strPass"]="1234";

	$strUsername = $_POST["email"];
	$strPassword = $_POST["password"];
	$strSQL = "SELECT * FROM Yaowarat_User WHERE 1 
		AND username = '".$strUsername."'  
		AND password = '".$strPassword."'  
		";

	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
	$intNumRows = mysql_num_rows($objQuery);
	if($intNumRows==0)
	{
		$arr['StatusID'] = "0"; 
		$arr['MemberID'] = "0"; 
		$arr['Error'] = "Incorrect Username and Password";	
	}
	else
	{
		$arr['StatusID'] = "1"; 
		$arr['MemberID'] = $objResult["MemberID"]; 
		$arr['Username'] = $objResult["Username"]; 
		$arr['Email'] = $objResult["Email"]; 
		$arr['Pic'] = $objResult["Pic"]; 

		$arr['Error'] = "";	
	}

	/*
		$arr['StatusID'] // (0=Failed , 1=Complete)
		$arr['MemberID'] // MemberID
		$arr['Error' // Error Message
	*/
	
	mysql_close($objConnect);
	
	echo json_encode($arr);

	if($objResult){
		echo "Success";
		header('Refresh: 1;url=all-review.php');
	}else{
		echo "0 result";
	}//end if result




