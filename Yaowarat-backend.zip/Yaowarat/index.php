<!DOCTYPE html>
<html>
<head>
	<title>Yaowaratch Admin : log in</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="tab-menu">
		<div class="logo"><img src="img/logo.png" height="49" width="53"></div>
		<div class="list-menu">
			<ul class="tab">
				 <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'London')">USER</a></li>
				 <li><a href="all-review.php" class="tablinks" onclick="openCity(event, 'Paris')">REVIEW</a></li>
				 <li><a href="add.php" class="tablinks" onclick="openCity(event, 'Tokyo')">ADD REVIEW</a></li>
			</ul>
		</div>
	</div><!-- tab-menu -->

<center>
	<form class="login-box" action="check-login.php" method="POST">
		<h3>Username    : </h3><input type="text" name="email" placeholder="Input email"><br>
		<h3>Password : </h3><input type="Password" name="password" placeholder="Input password">
		<center><BUTTON type="submit">Log in</BUTTON></center>
	</form>
</center>
</body>
</html>