<?php
  $objConnect = mysql_connect("ap-cdbr-azure-southeast-b.cloudapp.net","bb1c6298a02df8","b3da3e71");


  if(!$objConnect){
  	echo mysql_error();
  	echo mysql_errno();
  }
  $objDB = mysql_select_db("acsm_6f40e825d2a18e3");


?>