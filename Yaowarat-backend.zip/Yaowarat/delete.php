<?php include("connectSQL/connection.php"); ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Delete</title>
</head>
<body>
<?php
	$review_id = $_GET['id']; 
	echo $review_id;

	$sql = "DELETE FROM yaowarat_review WHERE review_id=$review_id";
	$query = mysql_query($sql);

	if($query){
		echo "Delete Success";
		header('Refresh: 1;url=all-review.php');
	}else{
		echo "0 result";
	}//end if result

	$conn -> close();
 ?>
</body>
</html>