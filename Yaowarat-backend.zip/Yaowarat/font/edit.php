<?php
	include("connectSQL/connection.php");

?>
<html>
<head>
	<title>ADD REVIEW</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<?php 
		$review_id_edit = $_GET['id'];
		echo "ID FOR EDIT MENU = ".$review_id_edit."<br>";
		require "connectSQL.php"; 

		$sql = "SELECT * FROM yaowarat_review WHERE review_id=$review_id_edit";
		$row = $conn -> query($sql);

		if($row -> num_rows > 0){
			while ($row = $result -> fetch_assoc()) {
				$reviewID = $row['review_id'];
				$reviewName = $row['review_name'];
				$reviewPrice = $row['review_price'];
				$reviewOpent = $row['review_opent'];
				$locationReview = $row['review_location'];
				$reviewReview = $row['review'];
				$reviewImg = $row['review_img'];	
			}
		}else{
			echo "0 result";
		}//end 0 result
			 
	?>
	<div id="tab-menu">
		<div class="logo"><img src="img/logo.png" height="49" width="53"></div>
		<div class="list-menu">
			<ul class="tab">
				 <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'London')">USER</a></li>
				 <li><a href="all-review.php" class="tablinks" onclick="openCity(event, 'Paris')">REVIEW</a></li>
				 <li><a href="add.php" class="tablinks" onclick="openCity(event, 'Tokyo')">ADD REVIEW</a></li>
			</ul>
		</div>
	</div><!-- tab-menu -->

	<center>
	<form class="add-box" action="success.php" method="post" enctype="multipart/form-data">
		<h3> Review Topic : </h3>
		<input type="text" placeholder="add topic" name="name" value="<?php echo $reviewName; ?>" required/><br>
		<h3> Rate Price : </h3>
		<input type="text" placeholder="rate price" name="price" value="<?php echo $reviewPrice; ?>" required/><br>
		<h3> Time Close : </h3>
		<input type="text" placeholder="time close" name="opent" value="<?php echo $reviewOpent; ?>" required/><br>
		<h3> Location : </h3>
		<input type="text" placeholder="location" name="location" value="<?php echo $locationReview; ?>" required/><br>
		<h3> Review Detail : </h3>
		<input type="text" placeholder="add review details" name="review" value="<?php echo $reviewReview; ?>" required/><br>
		<h3> Upload Photo : </h3>
		<input type="file" value="<?php echo $reviewImg; ?>" name="image" required/><br>

		<input name="hidAction" type="hidden" value="Add">
		<center> <button type="submit">ADD REVIEW</button> </center>
	</form>
	</center>
</body>
</html>